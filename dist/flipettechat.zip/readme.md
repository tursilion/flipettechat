20061118

Flipette Chat was originally written for STOS BASIC on the Atari ST. It was ported (loosely speaking) to QBASIC by removing or commenting out the STOS graphics commands. I don't think the original source exists anymore.

This code runs fine under Blassic - https://blassic.net/

It also runs under QB64 - https://qb64.org/

The software basically runs on the same concept as the old Eliza, the only improvements being basic substitution and remembering the last subject.
